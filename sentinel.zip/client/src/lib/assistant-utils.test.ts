import { describe, expect, it } from "vitest";
import { inspectSelectedFile, parseDatasetFile, summarizeNumericColumns } from "./assistant-utils";

function testFile(name: string, content: string, type = "text/plain"): File {
  return {
    name,
    size: new TextEncoder().encode(content).length,
    type,
    lastModified: 1,
    text: async () => content,
  } as File;
}

describe("assistant-utils", () => {
  it("parses quoted CSV cells and calculates numeric summaries locally", async () => {
    const dataset = await parseDatasetFile(testFile(
      "sample.csv",
      'name,value,note\nAlpha,2,"line, one"\nBeta,4,plain',
      "text/csv",
    ));

    expect(dataset.headers).toEqual(["name", "value", "note"]);
    expect(dataset.rows[0]).toEqual(["Alpha", "2", "line, one"]);
    expect(summarizeNumericColumns(dataset)).toEqual([
      { name: "value", count: 2, mean: 3, min: 2, max: 4 },
    ]);
  });

  it("parses JSON arrays of records", async () => {
    const dataset = await parseDatasetFile(testFile(
      "sample.json",
      JSON.stringify([{ city: "Oslo", count: 3 }, { city: "Lima", count: 6 }]),
      "application/json",
    ));

    expect(dataset.headers).toEqual(["city", "count"]);
    expect(dataset.rows).toEqual([["Oslo", "3"], ["Lima", "6"]]);
  });

  it("labels a matched script pattern as a heuristic indicator, not a verdict", async () => {
    const finding = await inspectSelectedFile(testFile(
      "review.ps1",
      "powershell.exe -encodedcommand ZABvAG4AdAByAHUAbgA=",
      "text/plain",
    ));

    expect(finding.risk).toBe("high");
    expect(finding.summary).toContain("heuristic");
    expect(finding.indicators.some(item => item.includes("Encoded PowerShell"))).toBe(true);
  });
});
