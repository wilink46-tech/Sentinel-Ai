export type Dataset = {
  filename: string;
  headers: string[];
  rows: string[][];
};

export type NumericSummary = {
  name: string;
  count: number;
  mean: number;
  min: number;
  max: number;
};

export type FileInspection = {
  id: string;
  name: string;
  size: number;
  risk: "low" | "medium" | "high";
  summary: string;
  indicators: string[];
  inspectedAt: number;
};

const MAX_DATASET_BYTES = 10 * 1024 * 1024;
const MAX_DATASET_ROWS = 10000;
const MAX_INSPECT_BYTES = 2 * 1024 * 1024;

function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = "";
  let quoted = false;
  const source = text.replace(/^\uFEFF/, "");

  for (let index = 0; index < source.length; index += 1) {
    const char = source[index];
    if (quoted) {
      if (char === '"' && source[index + 1] === '"') {
        field += '"';
        index += 1;
      } else if (char === '"') {
        quoted = false;
      } else {
        field += char;
      }
      continue;
    }

    if (char === '"' && field.length === 0) {
      quoted = true;
    } else if (char === ",") {
      row.push(field);
      field = "";
    } else if (char === "\n" || char === "\r") {
      if (char === "\r" && source[index + 1] === "\n") index += 1;
      row.push(field);
      field = "";
      if (row.some(value => value.trim() !== "")) rows.push(row);
      row = [];
      if (rows.length > MAX_DATASET_ROWS + 1) {
        throw new Error(`Datasets are limited to ${MAX_DATASET_ROWS.toLocaleString()} rows.`);
      }
    } else {
      field += char;
    }
  }

  row.push(field);
  if (row.some(value => value.trim() !== "")) rows.push(row);
  return rows;
}

function normalizeJson(value: unknown): string[][] {
  const records = Array.isArray(value)
    ? value
    : value && typeof value === "object" && Array.isArray((value as { data?: unknown }).data)
      ? (value as { data: unknown[] }).data
      : null;
  if (!records || records.length === 0 || !records.every(item => item && typeof item === "object" && !Array.isArray(item))) {
    throw new Error("JSON data must be a non-empty array of objects, or an object containing a data array.");
  }
  if (records.length > MAX_DATASET_ROWS) {
    throw new Error(`Datasets are limited to ${MAX_DATASET_ROWS.toLocaleString()} rows.`);
  }
  const headers = [...new Set(records.flatMap(item => Object.keys(item as Record<string, unknown>)))];
  if (headers.length === 0) throw new Error("The selected JSON file has no data columns.");
  const rows = records.map(item => headers.map(header => {
    const cell = (item as Record<string, unknown>)[header];
    if (cell === null || cell === undefined) return "";
    return typeof cell === "object" ? JSON.stringify(cell) : String(cell);
  }));
  return [headers, ...rows];
}

export async function parseDatasetFile(file: File): Promise<Dataset> {
  if (file.size > MAX_DATASET_BYTES) {
    throw new Error("Choose a CSV or JSON file smaller than 10 MB. Files are parsed locally in your browser.");
  }
  const text = await file.text();
  const isJson = file.name.toLowerCase().endsWith(".json") || file.type.includes("json");
  const parsed = isJson ? normalizeJson(JSON.parse(text) as unknown) : parseCsv(text);
  if (parsed.length < 2 || parsed[0].length === 0) {
    throw new Error("This file needs a header row and at least one data row.");
  }
  const headers = parsed[0].map((header, index) => header.trim() || `Column ${index + 1}`);
  const rows = parsed.slice(1).map(row => headers.map((_, index) => row[index] ?? ""));
  return { filename: file.name, headers, rows };
}

export function summarizeNumericColumns(dataset: Dataset): NumericSummary[] {
  return dataset.headers.flatMap((name, columnIndex) => {
    const values = dataset.rows
      .map(row => row[columnIndex]?.trim() ?? "")
      .filter(value => value !== "")
      .map(value => Number(value.replace(/,/g, "")))
      .filter(Number.isFinite);
    if (values.length === 0) return [];
    const total = values.reduce((sum, value) => sum + value, 0);
    return [{
      name,
      count: values.length,
      mean: total / values.length,
      min: Math.min(...values),
      max: Math.max(...values),
    }];
  });
}

const riskyExtensions = new Set(["exe", "dll", "scr", "bat", "cmd", "ps1", "vbs", "js", "jar", "msi", "apk", "sh"]);
const suspiciousPatterns: Array<{ pattern: RegExp; label: string; risk: "medium" | "high" }> = [
  { pattern: /powershell(?:\.exe)?\s+[^\n]{0,80}-(?:enc|encodedcommand)\b/i, label: "Encoded PowerShell invocation", risk: "high" },
  { pattern: /(?:downloadstring|invoke-webrequest|curl\s+[^\n|]+\s*\|\s*(?:sh|bash))/i, label: "Possible remote-download-and-run pattern", risk: "high" },
  { pattern: /(?:child_process\.exec|exec\s*\(\s*["'`]\s*(?:cmd|powershell|sh))/i, label: "Code that may launch a system process", risk: "medium" },
  { pattern: /(?:eval\s*\(|new\s+Function\s*\(|frombase64string\s*\()/i, label: "Dynamic or encoded-code pattern", risk: "medium" },
  { pattern: /(?:disabledefender|add-mppreference|reg\s+add\s+[^\n]*run)/i, label: "Possible security-setting or persistence change", risk: "high" },
];

export async function inspectSelectedFile(file: File): Promise<FileInspection> {
  const indicators: string[] = [];
  const extension = file.name.split(".").pop()?.toLowerCase() ?? "";
  if (riskyExtensions.has(extension)) {
    indicators.push(`File type .${extension} can contain executable or active content.`);
  }
  let text: string | undefined;
  const likelyText = /^(text\/|application\/(json|javascript|xml|x-sh|x-python|sql))/i.test(file.type)
    || /\.(txt|csv|json|xml|html?|css|js|ts|py|sh|ps1|bat|cmd|vbs|sql|md)$/i.test(file.name);
  if (likelyText && file.size <= MAX_INSPECT_BYTES) {
    try {
      text = await file.text();
    } catch {
      indicators.push("The browser could not read this file as text.");
    }
  } else if (likelyText && file.size > MAX_INSPECT_BYTES) {
    indicators.push("Text inspection was skipped because the file exceeds the 2 MB local-check limit.");
  } else {
    indicators.push("Content inspection was skipped for this binary or unsupported file type.");
  }

  let highest: "low" | "medium" | "high" = "low";
  if (text) {
    for (const item of suspiciousPatterns) {
      if (item.pattern.test(text)) {
        indicators.push(item.label);
        if (item.risk === "high") highest = "high";
        else if (highest === "low") highest = "medium";
      }
    }
  }
  if (riskyExtensions.has(extension) && highest === "low") highest = "medium";
  if (highest === "low" && indicators.some(item => item.includes("skipped") || item.includes("could not"))) {
    indicators.push("This limited check did not inspect all file contents.");
  }
  const summary = highest === "high"
    ? "Multiple high-concern heuristic indicators were found; this is not proof of malware. Do not open or execute this file; use a trusted antivirus tool for a full scan."
    : highest === "medium"
      ? "A review indicator was found. This is not proof of malware; verify the source and scan with trusted security software."
      : "No listed indicators were found in the inspected portion. This is not proof that the file is safe.";

  return {
    id: `${file.name}-${file.lastModified}-${file.size}`,
    name: file.name,
    size: file.size,
    risk: highest,
    summary,
    indicators: indicators.length ? indicators : ["No matched indicators in the limited local heuristic check."],
    inspectedAt: Date.now(),
  };
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
