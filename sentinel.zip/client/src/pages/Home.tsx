import {
  Activity, BarChart3, Check, ChevronRight, CircleAlert, Clock3, Code2, Copy,
  FileText, Headphones, LockKeyhole, Menu, Mic, MicOff, Send, Settings2,
  Shield, ShieldCheck, ShieldAlert, Sparkles, Upload, Volume2, X,
} from "lucide-react";
import { lazy, Suspense, useEffect, useMemo, useRef, useState } from "react";
import { trpc } from "@/lib/trpc";
import {
  Dataset, FileInspection, formatBytes, inspectSelectedFile, parseDatasetFile,
  summarizeNumericColumns,
} from "@/lib/assistant-utils";

const Streamdown = lazy(() => import("streamdown").then(module => ({ default: module.Streamdown })));

type View = "assistant" | "code" | "data" | "security" | "activity" | "privacy";
type AssistantMode = "assistant" | "code" | "data" | "security";
type ChatMessage = { id: string; role: "user" | "assistant"; content: string; mode: AssistantMode; at: number };
type ActivityItem = { id: string; title: string; detail: string; type: "assistant" | "code" | "data" | "security" | "system"; at: number };

type RecognitionLike = {
  lang: string;
  interimResults: boolean;
  continuous: boolean;
  onresult: ((event: { resultIndex: number; results: ArrayLike<ArrayLike<{ transcript: string; isFinal?: boolean }>> }) => void) | null;
  onerror: ((event: { error?: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
};
type RecognitionCtor = new () => RecognitionLike;
type BrowserWithSpeech = Window & { SpeechRecognition?: RecognitionCtor; webkitSpeechRecognition?: RecognitionCtor };

const navigation: Array<{ key: View; label: string; icon: typeof Sparkles }> = [
  { key: "assistant", label: "Assistant", icon: Sparkles },
  { key: "code", label: "Code studio", icon: Code2 },
  { key: "data", label: "Data lab", icon: BarChart3 },
  { key: "security", label: "Security", icon: ShieldCheck },
  { key: "activity", label: "Activity center", icon: Activity },
  { key: "privacy", label: "Privacy & access", icon: LockKeyhole },
];
const viewText: Record<View, { title: string; eyebrow: string; description: string }> = {
  assistant: { title: "A clearer next step, by voice or text.", eyebrow: "Sentinel workspace", description: "Ask a question, work through code, or get help understanding a security concern." },
  code: { title: "Build, understand, and debug code.", eyebrow: "Code studio", description: "Get a careful second pair of eyes across popular programming languages." },
  data: { title: "Find the signal in your data.", eyebrow: "Data lab", description: "Import a CSV or JSON file for local summaries, tables, charts, and optional AI-assisted questions." },
  security: { title: "Review a file without running it.", eyebrow: "Security desk", description: "Run a limited, browser-local heuristic check on a file you choose." },
  activity: { title: "Recent work and security notes.", eyebrow: "Activity center", description: "Review commands, analysis, findings, statuses, and errors from this session." },
  privacy: { title: "You stay in control of what is shared.", eyebrow: "Privacy & access", description: "Manage optional browser-local history and understand microphone, file, and AI boundaries." },
};
const languages = ["Python", "JavaScript", "TypeScript", "Java", "C", "C++", "C#", "Go", "Rust", "PHP", "Ruby", "Swift", "Kotlin", "SQL", "R", "MATLAB", "Bash", "PowerShell", "HTML/CSS", "Other"];
const codeTasks = ["Generate", "Explain", "Debug", "Translate"];
const defaultSuggestions = ["Explain a code snippet in plain English", "Help me summarize a spreadsheet", "How can I check a suspicious file safely?"];
const retentionKey = "sentinel-retain-history";
const messagesKey = "sentinel-conversation";
const activityKey = "sentinel-activity";

function readSaved<T,>(key: string, fallback: T): T {
  try {
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) as T : fallback;
  } catch {
    return fallback;
  }
}
function readableTime(timestamp: number) {
  return new Date(timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}
function makeId() { return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`; }
function currentMode(view: View): AssistantMode {
  return view === "code" || view === "data" || view === "security" ? view : "assistant";
}
function activityTypeFor(mode: AssistantMode): ActivityItem["type"] { return mode; }

export default function Home() {
  const [view, setView] = useState<View>("assistant");
  const [retainHistory, setRetainHistory] = useState(() => {
    try { return localStorage.getItem(retentionKey) === "true"; } catch { return false; }
  });
  const [messages, setMessages] = useState<ChatMessage[]>(() => retainHistory ? readSaved(messagesKey, []) : []);
  const [activity, setActivity] = useState<ActivityItem[]>(() => retainHistory ? readSaved(activityKey, []) : []);
  const [allowDatasetShare, setAllowDatasetShare] = useState(false);
  const [allowSecurityShare, setAllowSecurityShare] = useState(false);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [listening, setListening] = useState(false);
  const [voiceStage, setVoiceStage] = useState<"idle" | "listening" | "transcribing" | "processing" | "response">("idle");
  const [notice, setNotice] = useState("");
  const [language, setLanguage] = useState("Python");
  const [codeTask, setCodeTask] = useState("Generate");
  const [dataset, setDataset] = useState<Dataset | null>(null);
  const [dataError, setDataError] = useState("");
  const [dataLoading, setDataLoading] = useState(false);
  const [inspections, setInspections] = useState<FileInspection[]>([]);
  const [scanLoading, setScanLoading] = useState(false);
  const [selectedFinding, setSelectedFinding] = useState<FileInspection | null>(null);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const recognitionRef = useRef<RecognitionLike | null>(null);
  const finalTranscriptRef = useRef("");
  const chatEndRef = useRef<HTMLDivElement>(null);
  const assistantMutation = trpc.assistant.ask.useMutation();
  const mode = currentMode(view);
  const stats = useMemo(() => dataset ? summarizeNumericColumns(dataset) : [], [dataset]);
  const content = viewText[view];
  const currentMessages = messages.filter(message => message.mode === mode);

  useEffect(() => {
    try {
      if (!retainHistory) {
        localStorage.removeItem(retentionKey);
        localStorage.removeItem(messagesKey);
        localStorage.removeItem(activityKey);
        return;
      }
      localStorage.setItem(retentionKey, "true");
      localStorage.setItem(messagesKey, JSON.stringify(messages));
      localStorage.setItem(activityKey, JSON.stringify(activity));
    } catch {
      setNotice("Browser storage is unavailable, so history will remain only for this session.");
    }
  }, [retainHistory, messages, activity]);

  const pushActivity = (item: Omit<ActivityItem, "id" | "at">) => {
    const next = { ...item, id: makeId(), at: Date.now() };
    setActivity(previous => [next, ...previous].slice(0, 100));
  };

  const datasetContext = () => {
    if (!dataset || !allowDatasetShare) return undefined;
    const numeric = summarizeNumericColumns(dataset).map(column => ({
      column: column.name,
      count: column.count,
      mean: Number(column.mean.toFixed(4)),
      min: column.min,
      max: column.max,
    }));
    const sampleRows = dataset.rows.slice(0, 20).map(row => Object.fromEntries(dataset.headers.map((header, index) => [header, row[index] ?? ""])));
    return JSON.stringify({ totalRows: dataset.rows.length, columns: dataset.headers, numericSummary: numeric, sampleRows }).slice(0, 12000);
  };

  const sendPrompt = async (rawText = input) => {
    const prompt = rawText.trim();
    if (!prompt || busy) return;
    if (view === "data" && dataset && !allowDatasetShare) {
      setNotice("Your file stays in this browser. To ask AI about it, explicitly enable “Share up to 20 sample rows with AI” below the dataset.");
      return;
    }
    setNotice("");
    const userMessage: ChatMessage = { id: makeId(), role: "user", content: prompt, mode, at: Date.now() };
    const historySharingAllowed = (mode !== "data" || allowDatasetShare) && (mode !== "security" || allowSecurityShare);
    const history = historySharingAllowed
      ? messages.filter(message => message.mode === mode).slice(-8).map(message => ({ role: message.role, content: message.content.slice(0, 3500) }))
      : [];
    setMessages(previous => [...previous, userMessage].slice(-50));
    setInput("");
    setBusy(true);
    setVoiceStage("processing");
    const requestPrompt = mode === "code"
      ? `${codeTask} ${language} code. User request: ${prompt}`
      : prompt;
    let context = mode === "data" ? datasetContext() : undefined;
    if (mode === "security" && inspections.length && allowSecurityShare) {
      context = JSON.stringify(inspections.slice(0, 8).map(file => ({ name: file.name, risk: file.risk, indicators: file.indicators, summary: file.summary })));
    }
    pushActivity({ type: activityTypeFor(mode), title: mode === "code" ? `Code ${codeTask.toLowerCase()} request` : mode === "data" ? "Data question" : mode === "security" ? "Security guidance request" : "Assistant conversation", detail: prompt.slice(0, 120) });
    try {
      const result = await assistantMutation.mutateAsync({
        mode,
        prompt: requestPrompt,
        language: mode === "code" ? language : undefined,
        task: mode === "code" ? codeTask : undefined,
        context,
        history,
      });
      const response: ChatMessage = { id: makeId(), role: "assistant", content: result.text, mode, at: Date.now() };
      setMessages(previous => [...previous, response].slice(-50));
      pushActivity({ type: "assistant", title: "Assistant response ready", detail: `${mode === "code" ? language + " · " : ""}${result.text.replace(/\s+/g, " ").slice(0, 110)}` });
      setVoiceStage("response");
    } catch (error) {
      const message = error instanceof Error ? error.message : "The request could not be completed.";
      setNotice(message);
      pushActivity({ type: "system", title: "Assistant request failed", detail: message });
      setVoiceStage("idle");
    } finally {
      setBusy(false);
      window.setTimeout(() => chatEndRef.current?.scrollIntoView({ behavior: "smooth", block: "end" }), 60);
    }
  };

  const startOrStopListening = () => {
    if (listening && recognitionRef.current) {
      recognitionRef.current.stop();
      return;
    }
    const browser = window as BrowserWithSpeech;
    const Recognition = browser.SpeechRecognition ?? browser.webkitSpeechRecognition;
    if (!Recognition) {
      setNotice("Speech recognition is unavailable in this browser. You can still type your command. Try a current desktop Chrome or Edge browser for click-to-talk.");
      return;
    }
    setNotice("Your browser's speech service may process the audio to recognize words. Sentinel does not record or store microphone audio.");
    finalTranscriptRef.current = "";
    const recognition = new Recognition();
    recognition.lang = navigator.language || "en-US";
    recognition.interimResults = true;
    recognition.continuous = false;
    recognition.onresult = event => {
      let interim = "";
      for (let index = event.resultIndex; index < event.results.length; index += 1) {
        const result = event.results[index];
        const transcript = result?.[0]?.transcript ?? "";
        if (result?.[0]?.isFinal) finalTranscriptRef.current += `${transcript} `;
        else interim += transcript;
      }
      setInput(`${finalTranscriptRef.current}${interim}`.trim());
      setVoiceStage("transcribing");
    };
    recognition.onerror = event => {
      const reason = event.error === "not-allowed" ? "Microphone permission was denied. Type your request instead, or enable permission in your browser settings." : `Speech recognition stopped${event.error ? ` (${event.error})` : ""}. You can type your request instead.`;
      setNotice(reason);
      setListening(false);
      setVoiceStage("idle");
    };
    recognition.onend = () => {
      setListening(false);
      recognitionRef.current = null;
      const spoken = finalTranscriptRef.current.trim();
      finalTranscriptRef.current = "";
      if (spoken) {
        setVoiceStage("transcribing");
        void sendPrompt(spoken);
      } else {
        setVoiceStage("idle");
      }
    };
    recognitionRef.current = recognition;
    setListening(true);
    setVoiceStage("listening");
    try {
      recognition.start();
    } catch {
      recognitionRef.current = null;
      setListening(false);
      setVoiceStage("idle");
      setNotice("The microphone could not start. Check browser permission and try again.");
    }
  };

  const loadDataset = async (file?: File) => {
    if (!file) return;
    setDataError("");
    setDataLoading(true);
    try {
      const next = await parseDatasetFile(file);
      const numericSummary = summarizeNumericColumns(next);
      setMessages(previous => previous.filter(message => message.mode !== "data"));
      setDataset(next);
      setAllowDatasetShare(false);
      pushActivity({ type: "data", title: "Dataset imported locally", detail: `${file.name} · ${next.rows.length.toLocaleString()} rows · ${next.headers.length} columns` });
      const summaryDetail = numericSummary.length
        ? numericSummary.slice(0, 3).map(column => `${column.name}: mean ${column.mean.toFixed(2)}, min ${column.min}, max ${column.max}`).join(" · ")
        : "No numeric columns were found.";
      pushActivity({ type: "data", title: "Local data summary calculated", detail: `${next.rows.length.toLocaleString()} rows · ${summaryDetail}` });
    } catch (error) {
      const message = error instanceof Error ? error.message : "The file could not be read.";
      setDataError(message);
      setDataset(null);
      setAllowDatasetShare(false);
      setMessages(previous => previous.filter(item => item.mode !== "data"));
      pushActivity({ type: "system", title: "Dataset import failed", detail: message });
    } finally {
      setDataLoading(false);
    }
  };

  const inspectFiles = async (files: FileList | null) => {
    if (!files?.length) return;
    setScanLoading(true);
    try {
      const results = await Promise.all(Array.from(files).slice(0, 10).map(inspectSelectedFile));
      setMessages(previous => previous.filter(message => message.mode !== "security"));
      setAllowSecurityShare(false);
      setInspections(previous => [...results, ...previous].slice(0, 20));
      results.forEach(result => pushActivity({ type: "security", title: `${result.risk.toUpperCase()} heuristic indicator`, detail: `${result.name} · ${result.summary} · ${result.indicators.join("; ")}` }));
    } catch (error) {
      const message = error instanceof Error ? error.message : "The local file check could not be completed.";
      setNotice(message);
      pushActivity({ type: "system", title: "Local file check failed", detail: message });
    } finally {
      setScanLoading(false);
    }
  };

  const speak = (text: string) => {
    if (!("speechSynthesis" in window)) {
      setNotice("Spoken playback is not supported in this browser.");
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text.slice(0, 5000));
    utterance.lang = navigator.language || "en-US";
    window.speechSynthesis.speak(utterance);
  };

  const clearHistory = () => {
    setMessages([]);
    setActivity([]);
    try {
      localStorage.removeItem(messagesKey);
      localStorage.removeItem(activityKey);
      setNotice("Conversation and activity history cleared from this browser session and local storage.");
    } catch {
      setNotice("Current session history was cleared, but browser storage could not be accessed.");
    }
  };

  const renderChat = () => (
    <section className="panel chat-panel">
      <div className="chat-toolbar">
        <div className="chat-toolbar-label"><span className="assistant-avatar"><Sparkles size={14} /></span><span>{view === "code" ? "Code companion" : view === "data" ? "Ask about your data" : view === "security" ? "Security guide" : "Sentinel assistant"}</span></div>
        <div className="mode-note" aria-live="polite"><LockKeyhole size={12} /> {voiceStage === "idle" ? "Voice ready" : voiceStage === "listening" ? "Listening" : voiceStage === "transcribing" ? "Transcribing" : voiceStage === "processing" ? "Processing" : "Response ready"} · reviewable guidance, no system commands</div>
      </div>
      <div className="chat-scroll" aria-live="polite">
        {currentMessages.length === 0 ? (
          <div className="empty-state">
            <div className="empty-orbit"><Sparkles size={22} /></div>
            <h3>{view === "code" ? "What are you building?" : view === "data" ? "Ask a question about your dataset" : view === "security" ? "Tell me what you noticed" : "Tell me what you want to work through."}</h3>
            <p>{view === "data" && dataset && !allowDatasetShare ? "Local summaries are ready below. Enable sample sharing before asking AI about the file." : "Your requests stay reviewable. Sentinel offers guidance and does not control the computer itself."}</p>
            {view === "assistant" && <div className="suggestion-row">{defaultSuggestions.map(suggestion => <button className="suggestion" key={suggestion} onClick={() => setInput(suggestion)}>{suggestion}</button>)}</div>}
          </div>
        ) : currentMessages.slice(-24).map(message => (
          <div className={`message-row ${message.role}`} key={message.id}>
            <div className="message-avatar">{message.role === "assistant" ? <Sparkles size={13} /> : <Headphones size={13} />}</div>
            <div>
              <div className="message-meta"><span>{message.role === "assistant" ? "Sentinel" : "You"}</span><span>·</span><span>{readableTime(message.at)}</span>{message.role === "assistant" && message.mode === "code" && <><span>·</span><span>{language}</span></>}</div>
              <div className="message-bubble">{message.role === "assistant" ? <div className="streamdown"><Suspense fallback={<span>Formatting response…</span>}><Streamdown>{message.content}</Streamdown></Suspense></div> : message.content}
                {message.role === "assistant" && <div className="message-actions"><button className="inline-action" onClick={() => speak(message.content)}><Volume2 size={12} /> Read aloud</button><button className="inline-action" onClick={() => void navigator.clipboard?.writeText(message.content)}><Copy size={12} /> Copy</button></div>}
              </div>
            </div>
          </div>
        ))}
        {busy && <div className="typing"><span className="typing-dots"><i /><i /><i /></span>Sentinel is thinking through your request…</div>}
        <div ref={chatEndRef} />
      </div>
      {notice && <div className={`notice ${notice.toLowerCase().includes("could not") || notice.toLowerCase().includes("failed") ? "warning" : "info"}`}><CircleAlert size={13} /> <span>{notice}</span></div>}
      {view === "data" && dataset && <div className="notice info"><LockKeyhole size={13} /><span>{allowDatasetShare ? "Dataset sharing is on: up to 20 sample rows and calculated summaries accompany Data Lab AI requests until you turn it off. The original file stays in your browser." : "Dataset sharing is off. To ask AI about this file, opt in below; up to 20 sample rows and summaries are shared only while the setting is on."}</span></div>}
      {view === "security" && inspections.length > 0 && <div className="notice info"><LockKeyhole size={13} /><label className="share-check"><input type="checkbox" checked={allowSecurityShare} onChange={event => setAllowSecurityShare(event.target.checked)} /><span><strong>Include up to 8 local findings in security questions.</strong> Off by default. While enabled, selected filenames, risk labels, and heuristic indicators are included with Security AI requests until you turn this off.</span></label></div>}
      <div className="composer-wrap">
        {view === "code" && <div className="composer-controls" style={{ justifyContent: "flex-start", padding: "0 2px 8px" }}><select className="select-control" aria-label="Programming task" value={codeTask} onChange={event => setCodeTask(event.target.value)}>{codeTasks.map(task => <option key={task}>{task}</option>)}</select><select className="language-select" aria-label="Programming language" value={language} onChange={event => setLanguage(event.target.value)}>{languages.map(item => <option key={item}>{item}</option>)}</select></div>}
        <form className="composer" onSubmit={event => { event.preventDefault(); void sendPrompt(); }}>
          <textarea aria-label="Your voice or text command" placeholder={listening ? "Listening — finish speaking or tap the microphone to stop…" : view === "code" ? `Ask for help with ${language} code…` : view === "data" ? "Ask a question about your dataset…" : view === "security" ? "Ask for safe, defensive security guidance…" : "Type a command or question…"} value={input} onChange={event => setInput(event.target.value)} onKeyDown={event => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); void sendPrompt(); } }} />
          <div className="composer-controls"><span className="composer-hint">Enter to send · Shift + Enter for a new line</span><div className="control-group"><button type="button" className={`icon-button ${listening ? "listening" : ""}`} aria-label={listening ? "Stop listening" : "Start voice input"} title={listening ? "Stop listening" : "Start voice input"} onClick={startOrStopListening} disabled={busy}>{listening ? <MicOff size={15} /> : <Mic size={15} />}</button><button className="send-button" type="submit" disabled={!input.trim() || busy}>{busy ? "Working…" : "Send"}<Send size={13} /></button></div></div>
        </form>
      </div>
    </section>
  );

  const renderAssistantView = () => (
    <div className="dashboard-grid">
      <div className="primary-stack">
        {view === "assistant" && <div className="welcome-strip"><div className="welcome-content"><h2>One calm place to think it through.</h2><p>Speak or type a request, then review the answer before taking action. Sentinel can guide you, but it cannot operate your device.</p></div><div className="welcome-badge"><ShieldCheck size={14} /> User stays in control</div></div>}
        {view === "code" && <div className="tool-card-grid"><div className="tool-card"><span className="tool-icon"><Code2 size={16} /></span><h3>Many languages</h3><p>Generate, explain, debug, or translate code with assumptions shown clearly.</p></div><div className="tool-card"><span className="tool-icon"><LockKeyhole size={16} /></span><h3>Nothing runs here</h3><p>Review code before using it. The assistant does not execute snippets or system commands.</p></div></div>}
          {view === "data" && <section className="panel"><div className="panel-head"><div><div className="panel-title"><BarChart3 size={15} /> Local data workspace</div><div className="panel-subtitle">CSV and JSON · parsed in this browser · up to 10 MB</div></div>{dataset && <button className="secondary-button" onClick={() => { setDataset(null); setAllowDatasetShare(false); setDataError(""); setMessages(previous => previous.filter(message => message.mode !== "data")); }}>Clear dataset</button>}</div><div className="panel-body">
          {!dataset && <label className="upload-zone"><input type="file" accept=".csv,.json,text/csv,application/json" onChange={event => { void loadDataset(event.target.files?.[0]); event.currentTarget.value = ""; }} /><span className="upload-icon"><Upload size={17} /></span><strong>{dataLoading ? "Reading locally…" : "Choose a CSV or JSON file"}</strong><span>Your file is not uploaded. Use the picker to keep it local.</span></label>}
          {dataError && <div className="notice warning" style={{ margin: "11px 0 0" }}><CircleAlert size={13} />{dataError}</div>}
          {dataset && <div style={{ display: "grid", gap: 14 }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10, flexWrap: "wrap" }}><div><div className="panel-title"><FileText size={14} />{dataset.filename}</div><div className="panel-subtitle">{dataset.rows.length.toLocaleString()} rows · {dataset.headers.length} columns</div></div><span className="risk-pill low"><Check size={11} /> Imported locally</span></div>
            <div className="metric-grid"><div className="metric-card"><div className="metric-label">Rows</div><div className="metric-value">{dataset.rows.length.toLocaleString()}</div><div className="metric-foot">data records</div></div><div className="metric-card"><div className="metric-label">Columns</div><div className="metric-value">{dataset.headers.length}</div><div className="metric-foot">fields detected</div></div><div className="metric-card"><div className="metric-label">Numeric fields</div><div className="metric-value">{stats.length}</div><div className="metric-foot">summarized locally</div></div></div>
            {stats.length > 0 && <div><div className="panel-title" style={{ marginBottom: 12 }}>Average by numeric column</div><div className="chart-list">{stats.slice(0, 6).map(item => { const largest = Math.max(...stats.slice(0, 6).map(entry => Math.abs(entry.mean)), 1); return <div className="chart-row" key={item.name}><span className="chart-label" title={item.name}>{item.name}</span><span className="chart-track"><span className="chart-fill" style={{ display: "block", width: `${Math.max(4, Math.abs(item.mean) / largest * 100)}%` }} /></span><span className="chart-value">{item.mean.toLocaleString(undefined, { maximumFractionDigits: 2 })}</span></div>; })}</div></div>}
            <div><div className="panel-title" style={{ marginBottom: 9 }}>Data preview</div><div className="data-table-wrap"><table className="data-table"><thead><tr>{dataset.headers.slice(0, 8).map(header => <th key={header}>{header}</th>)}</tr></thead><tbody>{dataset.rows.slice(0, 5).map((row, rowIndex) => <tr key={`${rowIndex}-${row[0]}`}>{dataset.headers.slice(0, 8).map((header, columnIndex) => <td key={`${header}-${columnIndex}`}>{row[columnIndex]}</td>)}</tr>)}</tbody></table></div></div>
            <label className="share-check"><input type="checkbox" checked={allowDatasetShare} onChange={event => setAllowDatasetShare(event.target.checked)} /><span><strong>Share up to 20 sample rows with AI for Data Lab questions.</strong> Optional and off by default. While enabled, a capped sample and summary accompany each Data Lab request; the original file remains in this browser.</span></label>
          </div>}
        </div></section>}
        {view === "security" && <section className="panel"><div className="panel-head"><div><div className="panel-title"><ShieldCheck size={15} /> Local file indicators</div><div className="panel-subtitle">Choose files to check selected text and file metadata only</div></div>{inspections.length > 0 && <button className="secondary-button" onClick={() => { setInspections([]); setAllowSecurityShare(false); setMessages(previous => previous.filter(message => message.mode !== "security")); }}>Clear results</button>}</div><div className="panel-body">
          <div className="risk-intro"><CircleAlert size={14} /><span>This is a limited heuristic check, not antivirus. Sentinel cannot scan your whole device, inspect process activity, or quarantine/delete files. Nothing you select is uploaded or executed.</span></div>
          <label className="upload-zone"><input type="file" multiple onChange={event => { void inspectFiles(event.target.files); event.currentTarget.value = ""; }} /><span className="upload-icon"><Shield size={17} /></span><strong>{scanLoading ? "Checking selected files locally…" : "Select up to 10 files for a local check"}</strong><span>Readable files are checked up to 2 MB. Binary contents are not inspected.</span></label>
          {inspections.length > 0 && <div style={{ marginTop: 15 }}><div className="panel-title" style={{ marginBottom: 10 }}>Recent indicators</div>{inspections.map(finding => <div className="finding-card" key={finding.id}><div className="finding-top"><div className="finding-name"><FileText size={13} />{finding.name}<span style={{ color: "#94a2ad", fontWeight: 400 }}>· {formatBytes(finding.size)}</span></div><span className={`risk-pill ${finding.risk}`}>{finding.risk} indicator</span></div><p className="finding-summary">{finding.summary}</p><div className="indicator-list">{finding.indicators.map(indicator => <span className="indicator-tag" key={indicator}>{indicator}</span>)}</div><div style={{ display: "flex", justifyContent: "flex-end", marginTop: 9 }}><button className="secondary-button" onClick={() => setSelectedFinding(finding)}>Review safe next steps <ChevronRight size={12} /></button></div></div>)}</div>}
        </div></section>}
        {view === "assistant" && <div className="tool-card-grid"><div className="tool-card"><span className="tool-icon"><Code2 size={16} /></span><h3>Programming companion</h3><p>Draft, explain, debug, and translate code across many languages.</p></div><div className="tool-card"><span className="tool-icon"><BarChart3 size={16} /></span><h3>Local data lab</h3><p>Parse CSV or JSON in your browser, then opt in before sharing a small sample.</p></div></div>}
        {view !== "activity" && view !== "privacy" && renderChat()}
      </div>
      <div className="secondary-stack">
        {view === "assistant" && <>
          <section className="panel"><div className="panel-head"><div><div className="panel-title"><ShieldCheck size={15} /> Protection, honestly</div><div className="panel-subtitle">What this browser app can do</div></div></div><div className="panel-body"><div className="risk-pill low"><Check size={11} /> Guidance ready</div><p style={{ color: "#718394", fontSize: 11, lineHeight: 1.6, margin: "10px 0 13px" }}>I can explain risk signals and safe response steps. I cannot watch your device or replace installed security software.</p><button className="secondary-button" onClick={() => setView("security")}>Open security desk <ChevronRight size={12} /></button></div></section>
          <section className="panel"><div className="panel-head"><div><div className="panel-title"><Clock3 size={15} /> Recent activity</div><div className="panel-subtitle">{activity.length} item{activity.length === 1 ? "" : "s"} this session</div></div><button className="icon-button" title="Open activity center" onClick={() => setView("activity")}><ChevronRight size={14} /></button></div><div className="panel-body">{activity.length === 0 ? <div className="empty-list">Your recent work will appear here.</div> : activity.slice(0, 4).map(item => <div className="activity-item" key={item.id}><span className="activity-icon">{item.type === "security" ? <Shield size={13} /> : item.type === "data" ? <BarChart3 size={13} /> : item.type === "code" ? <Code2 size={13} /> : <Sparkles size={13} />}</span><div><div className="activity-title">{item.title}</div><div className="activity-description">{item.detail}</div></div><span className="activity-time">{readableTime(item.at)}</span></div>)}</div></section>
        </>}
        {view === "code" && <section className="panel"><div className="panel-head"><div><div className="panel-title"><Shield size={15} /> Code safety</div><div className="panel-subtitle">Review before running</div></div></div><div className="panel-body"><ul className="safe-list"><li><Check size={13} />Outputs are suggestions, not executed code.</li><li><Check size={13} />Share secrets only after removing them from snippets.</li><li><Check size={13} />Ask for tests or edge cases when it matters.</li></ul></div></section>}
        {view === "data" && <section className="panel"><div className="panel-head"><div><div className="panel-title"><LockKeyhole size={15} /> Data handling</div><div className="panel-subtitle">Local first</div></div></div><div className="panel-body"><div className="policy-row"><LockKeyhole size={15} /><div><strong>File parsed in your browser</strong><span>Nothing is sent unless you opt in to include a capped sample in AI questions.</span></div></div><div className="footer-note"><CircleAlert size={12} />Remove personal or confidential fields before sharing. AI responses can be wrong; verify important conclusions.</div></div></section>}
        {view === "security" && <section className="panel"><div className="panel-head"><div><div className="panel-title"><ShieldAlert size={15} /> If a file worries you</div><div className="panel-subtitle">A cautious response path</div></div></div><div className="panel-body"><ul className="safe-list"><li><Check size={13} />Do not open, run, or share a suspicious file.</li><li><Check size={13} />Use trusted, updated security software for a full scan.</li><li><Check size={13} />If an incident seems active, ask your IT/security professional for help.</li></ul></div></section>}
        {(view === "activity" || view === "privacy") && <section className="panel"><div className="panel-head"><div><div className="panel-title"><LockKeyhole size={15} /> Your control</div><div className="panel-subtitle">Private by default</div></div></div><div className="panel-body"><p style={{ margin: 0, color: "#78899a", fontSize: 11, lineHeight: 1.6 }}>Conversation and activity history stay in this browser session unless you explicitly enable local retention. The assistant's AI responses are generated server-side.</p><button className="secondary-button" style={{ marginTop: 12 }} onClick={() => setView("privacy")}>Privacy settings <ChevronRight size={12} /></button></div></section>}
      </div>
    </div>
  );

  const renderActivity = () => (
    <section className="panel"><div className="panel-head"><div><div className="panel-title"><Activity size={15} /> Session timeline</div><div className="panel-subtitle">Activity is private to this session unless local retention is enabled.</div></div><button className="danger-button" onClick={clearHistory}>Clear history</button></div><div className="panel-body">{activity.length === 0 ? <div className="empty-list">Nothing to show yet. Your assistant requests and local file/data actions will appear here.</div> : <div className="activity-list">{activity.map(item => <div className="activity-item" key={item.id}><span className="activity-icon">{item.type === "security" ? <Shield size={13} /> : item.type === "data" ? <BarChart3 size={13} /> : item.type === "code" ? <Code2 size={13} /> : item.type === "system" ? <CircleAlert size={13} /> : <Sparkles size={13} />}</span><div><div className="activity-title">{item.title}</div><div className="activity-description">{item.detail}</div></div><span className="activity-time">{new Date(item.at).toLocaleString()}</span></div>)}</div>}</div></section>
  );

  const renderPrivacy = () => (
    <div className="dashboard-grid"><div className="primary-stack"><section className="panel"><div className="panel-head"><div><div className="panel-title"><Settings2 size={15} /> Privacy controls</div><div className="panel-subtitle">These settings apply in this browser.</div></div></div><div className="panel-body">
      <div className="setting-row"><div><div className="setting-title">Keep chat and activity on this device</div><div className="setting-description">Off by default. When enabled, recent conversations and activity details—including file names, heuristic findings, and local numeric summaries—are stored in browser local storage. Anyone using this browser profile may be able to see them.</div></div><button className={`switch ${retainHistory ? "on" : ""}`} role="switch" aria-checked={retainHistory} aria-label="Retain conversation and activity history" onClick={() => setRetainHistory(previous => !previous)}><span /></button></div>
      <div className="setting-row"><div><div className="setting-title">Share dataset sample with AI</div><div className="setting-description">Off by default. In Data Lab, while enabled, up to 20 sample rows and calculated summaries accompany every question. This preference resets when the page reloads or a different file is loaded.</div></div><button className={`switch ${allowDatasetShare ? "on" : ""}`} role="switch" aria-checked={allowDatasetShare} aria-label="Allow dataset sample sharing" onClick={() => setAllowDatasetShare(previous => !previous)}><span /></button></div>
      <div className="setting-row"><div><div className="setting-title">Share security findings with AI</div><div className="setting-description">Off by default. In Security, while enabled, up to 8 selected filenames, risk labels, and heuristic indicators accompany each question. This preference resets when the page reloads or new files are checked.</div></div><button className={`switch ${allowSecurityShare ? "on" : ""}`} role="switch" aria-checked={allowSecurityShare} aria-label="Allow security findings sharing" onClick={() => setAllowSecurityShare(previous => !previous)}><span /></button></div>
      <button className="danger-button" onClick={clearHistory}>Clear stored and current history</button>
    </div></section>
    <section className="panel"><div className="panel-head"><div><div className="panel-title"><LockKeyhole size={15} /> Access & permissions</div><div className="panel-subtitle">No permissions are requested in the background.</div></div></div><div className="panel-body">
      <div className="policy-row"><Mic size={15} /><div><strong>Microphone</strong><span>Only requested when you click the microphone. Browser speech recognition may process audio using your browser's speech service. Sentinel does not record or store raw audio.</span></div></div>
      <div className="policy-row"><FileText size={15} /><div><strong>File access</strong><span>Only files you choose. Dataset parsing and heuristic inspection happen in this browser; selected files are not uploaded or executed.</span></div></div>
      <div className="policy-row"><Code2 size={15} /><div><strong>Command execution</strong><span>Disabled. Sentinel cannot run commands, change system settings, terminate processes, or isolate/delete files.</span></div></div>
      <div className="policy-row"><ShieldCheck size={15} /><div><strong>Malware protection</strong><span>This app is not antivirus or endpoint protection. Use trusted, updated security software for device-wide scanning and remediation.</span></div></div>
      <div className="footer-note"><CircleAlert size={12} />Never enter passwords, API keys, recovery phrases, or sensitive personal data into an AI prompt. Verify generated code and analysis before relying on it.</div>
    </div></section></div><div className="secondary-stack"><section className="panel"><div className="panel-head"><div><div className="panel-title"><ShieldCheck size={15} /> Safe by design</div><div className="panel-subtitle">Explicit user control</div></div></div><div className="panel-body"><ul className="safe-list"><li><Check size={13} />Microphone starts only after a click.</li><li><Check size={13} />Data stays local until you opt in.</li><li><Check size={13} />Files are never executed by the app.</li><li><Check size={13} />System actions are never automated.</li></ul></div></section></div></div>
  );

  const selectView = (key: View) => { setView(key); setMobileNavOpen(false); setNotice(""); };
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand"><span className="brand-mark"><svg viewBox="0 0 24 24" width="21" height="21" fill="none" aria-hidden="true"><path d="M12 2.7 19 5v5.6c0 4.8-2.8 8.4-7 10.7-4.2-2.3-7-5.9-7-10.7V5l7-2.3Z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round"/><path d="m8.7 11.7 2.1 2.1 4.6-4.8" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/><path d="M18.8 7.2h2" stroke="#39b982" strokeWidth="1.6" strokeLinecap="round"/></svg></span><span className="brand-copy"><span className="brand-name">Sentinel</span><span className="brand-subtitle">AI workbench</span></span></div>
        <div className="nav-label">Workspace</div><nav className="nav-list" aria-label="Main navigation">{navigation.map(item => { const Icon = item.icon; return <button key={item.key} className={`nav-item ${view === item.key ? "active" : ""}`} onClick={() => selectView(item.key)}><Icon size={16} /><span>{item.label}</span></button>; })}</nav>
        <div className="sidebar-bottom"><div className="sidebar-status"><div className="status-line"><span className="status-dot" />Ready for your request</div><div className="status-caption">No background scan is running. Nothing can control your device.</div></div><div className="sidebar-footer">Sentinel AI · Preview workspace</div></div>
      </aside>
      {mobileNavOpen && <div className="modal-backdrop" onClick={() => setMobileNavOpen(false)}><div className="modal" onClick={event => event.stopPropagation()}><div className="modal-head"><div><h3>Workspace</h3><p>Choose a tool area.</p></div><button className="modal-close" onClick={() => setMobileNavOpen(false)}><X size={15} /></button></div><div className="nav-list" style={{ marginTop: 13 }}>{navigation.map(item => { const Icon = item.icon; return <button key={item.key} className={`nav-item ${view === item.key ? "active" : ""}`} style={{ color: view === item.key ? "#047857" : "#42566a", background: view === item.key ? "#eaf7f1" : "transparent" }} onClick={() => selectView(item.key)}><Icon size={16} /><span>{item.label}</span></button>; })}</div></div></div>}
      <main className="main-shell">
        <header className="topbar"><div className="topbar-left"><button className="top-icon mobile-menu" aria-label="Open navigation" onClick={() => setMobileNavOpen(true)}><Menu size={16} /></button><div className="crumb">Workspace <ChevronRight size={12} /> <strong>{navigation.find(item => item.key === view)?.label}</strong></div></div><div className="topbar-right"><span className="top-chip"><span className="status-dot" /> <span>AI ready · user-controlled</span></span><button className="top-icon" aria-label="Open privacy settings" title="Privacy & access" onClick={() => selectView("privacy")}><LockKeyhole size={15} /></button></div></header>
        <div className="page-wrap"><div className="page-heading"><div><div className="eyebrow"><ShieldCheck size={13} />{content.eyebrow}</div><h1>{content.title}</h1><p>{content.description}</p></div><div className="heading-tools">{view !== "activity" && view !== "privacy" && <button className="secondary-button" onClick={() => selectView("activity")}><Activity size={13} /> Activity</button>}</div></div>
          {view === "activity" ? renderActivity() : view === "privacy" ? renderPrivacy() : renderAssistantView()}
          <div className="footer-note" style={{ marginTop: 20 }}><LockKeyhole size={11} /><span>Sentinel provides AI guidance and limited local heuristics. It does not provide device-wide malware protection, antivirus scanning, or operating-system control.</span></div>
        </div>
      </main>
      {selectedFinding && <div className="modal-backdrop" role="presentation" onClick={() => setSelectedFinding(null)}><section className="modal" role="dialog" aria-modal="true" aria-labelledby="finding-title" onClick={event => event.stopPropagation()}><div className="modal-head"><div><h3 id="finding-title">Review safe next steps</h3><p>{selectedFinding.name} · {selectedFinding.risk} heuristic indicator. No file has been changed.</p></div><button className="modal-close" aria-label="Close" onClick={() => setSelectedFinding(null)}><X size={15} /></button></div><ul className="safe-list"><li><Check size={13} />Do not open, run, or share this file until you verify its source.</li><li><Check size={13} />Use trusted, updated security software to perform a full scan.</li><li><Check size={13} />If this is a work device, contact your IT/security team before moving or deleting anything.</li></ul><div className="notice warning" style={{ margin: 0 }}><CircleAlert size={13} /><span>Sentinel cannot quarantine or delete files. This confirmation only marks that you reviewed the guidance; it does not perform an action on your device.</span></div><div className="modal-actions"><button className="secondary-button" onClick={() => setSelectedFinding(null)}>Close</button><button className="primary-button" onClick={() => { pushActivity({ type: "security", title: "Safe steps reviewed", detail: `${selectedFinding.name} · no file action taken` }); setSelectedFinding(null); }}>I reviewed the safe steps <Check size={13} /></button></div></section></div>}
    </div>
  );
}
