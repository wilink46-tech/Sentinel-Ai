# TODO

## Voice command capture and assistant conversation
- [x] The app accepts spoken commands using an explicit user-started microphone interaction and shows listening, transcription/recognition, processing, response, and error/unsupported states.
- [x] Typed commands remain available as a fallback when microphone permission is denied or browser speech recognition is unavailable.
- [x] The assistant interprets natural-language requests conversationally, asks clarifying questions when intent or consequences are ambiguous, and keeps the user informed about what it can and cannot do.

## Reviewable actions and activity center
- [ ] The app previews consequential recommendations before confirmation, requires an explicit user approval step, and reports the result/status of the action. **Open:** Security safe-step guidance has a review acknowledgement and activity status, but a generic preview/approval workflow for all consequential assistant recommendations is not implemented. Sentinel intentionally cannot execute OS-level actions.
- [x] The assistant does not silently run host commands or make operating-system changes; the web app explains when a request requires actions outside its capabilities.
- [x] The activity center shows command history, analysis results, security findings, action status, and errors, with a clear-history control and optional browser-local history retention.

## Programming assistant
- [x] The assistant supports code generation, explanation, debugging, and translation across many programming languages, with a selectable language/task mode and clear assumptions.
- [x] AI output is presented as reviewable code or guidance rather than being executed automatically.

## Data analysis workspace
- [x] The workspace accepts user-selected CSV or JSON datasets, calculates local summaries, and presents useful tables and charts.
- [x] Users can ask natural-language questions about data; dataset contents stay local unless the user explicitly opts in to send a capped sample to the AI, and the app discloses that sharing before sending.

## Security and privacy controls
- [x] The security scanner checks only user-selected files and available file indicators for suspicious behavior, explains findings, and assigns understandable risk levels.
- [x] File inspection is bounded, local to the browser, never executes or uploads selected files, and labels results as heuristic indicators rather than a full antivirus or system-wide scan.
- [x] Malware response guidance recommends safe next steps and requires explicit confirmation for reviewed in-app actions; it does not claim to isolate or remove files from the user's system.
- [x] Privacy and permissions controls explain microphone access, selected-file access, command-execution limits, history retention, and sensitive-data handling.

## Product and safety scope
- [x] The application fulfills the request to build an AI that hears spoken commands, supports many programming languages, performs data analysis, and helps protect the user's system from malware, without claiming that a browser app can secure or scan the whole device.
