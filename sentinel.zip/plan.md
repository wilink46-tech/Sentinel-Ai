# Sentinel AI — Implementation Plan

## Product scope

Build a voice-first AI assistant that accepts spoken or typed natural-language requests, supports programming help across many languages, analyzes user-selected datasets, offers malware-safety guidance, and organizes activity and privacy controls. Preserve the confirmed Blueprint features: explicit voice states; ambiguity clarification; review-and-confirm for consequential actions; code generation/explanation/debugging/translation; local dataset import and conversational summaries; heuristic security checks for user-selected files; confirmed and safe response recommendations; activity history; and clear privacy/permission controls.

## Implementation approach

- Use the initialized React + TypeScript + Vite frontend and Express/tRPC server. Run AI requests through the server-side built-in Manus LLM helper; never expose service credentials in browser code.
- Implement click-to-talk using the browser Web Speech API where available, with typed input as an always-available fallback. Announce listening, processing, response, and unsupported-microphone states. Do not start recording until the user clicks.
- Treat assistant commands as suggestions and safe in-app workflows, not as authorization to operate the host operating system. Do not execute shell commands, alter settings, terminate processes, isolate, or delete user files. Ask a follow-up when intent or consequences are unclear. The file-remediation guidance uses an explicit review acknowledgement and records that no device action occurred; other consequential recommendations remain reviewable guidance that the user must confirm in trusted software or with a qualified human. Clearly report that this browser app cannot carry out OS-level actions.
- Support programming assistance through a language selector and task modes, with prompts emphasizing tested reasoning, explicit assumptions, and safe handling of untrusted code.
- Parse CSV/JSON datasets locally in the browser, calculate basic descriptive summaries locally, and render tables/charts from the locally parsed dataset. Keep uploaded file contents in-browser by default. Send only a capped sample to the AI after the user opts in, with a visible disclosure and a way to revoke that setting. Keep AI conversation history scoped to the active mode; never send data/security-mode history unless the corresponding sharing setting is enabled, and reset that mode's chat and sharing consent when a new file set is selected.
- Provide a client-side heuristic inspection of a user-selected file: inspect bounded, readable text and metadata only, never execute or upload the file. Label results as indicators rather than an antivirus verdict. Keep both dataset samples and security findings out of AI requests until the user explicitly opts in. Show recommended manual response steps; do not claim system-wide scanning or actual isolation/removal.
- Store conversation/activity only for the current session by default. Add an explicit opt-in for browser-local history, a clear-history control, and visible microphone/file/data-sharing permissions. The activity timeline includes requests, errors, local summary results, heuristic file findings, and review-status events; disclose that those details are persisted only when the user enables retention.

## Design

**Approved direction — Clinical Guardian.** A bright, high-trust security console built from cool white surfaces, deep navy structure, and precise emerald status cues; reassuring and analytical rather than ominous.

- **Design movement:** Contemporary clinical instrumentation and high-trust security operations UI.
- **Core principles:** Calm clarity; explain every risk; put user control before action; make status and provenance legible.
- **Color philosophy:** Cool white/blue-gray backgrounds keep the workspace open; deep navy provides structure; emerald marks verified/healthy states; amber and restrained red are reserved for caution and findings.
- **Layout paradigm:** A narrow persistent left rail, a utility/status header, and a flexible main workspace with an adjacent context/activity column; on small screens, the rail collapses into a top navigation and columns stack.
- **Signature elements:** A shield-shaped line mark; thin emerald status rules; small, labeled telemetry chips with plain-language meaning.
- **Interaction philosophy:** Microphone capture is click-to-start and click-to-stop; destructive or external actions are never implicit; show previews, scope, and confirmation language before any consequential in-app action.
- **Animation:** Short 140–220 ms transitions, subtle waveform motion only while actively listening, no ambient pulsing that implies a system scan is running.
- **Typography system:** IBM Plex Sans (or a robust system sans fallback) for interface text; IBM Plex Mono/system monospace for code and telemetry. Use clear size/weight hierarchy and readable line lengths.
- **Brand essence:** A calm AI workbench that turns voice, code, data, and security questions into reviewable next steps. Personality: clear, careful, capable.
- **Brand voice:** Direct, reassuring, non-alarmist. Example lines: “Tell me what you want to work through.” “This is a heuristic check, not an antivirus scan.”
- **Wordmark & logo:** “Sentinel” wordmark paired with a custom outlined shield built from simple inline SVG strokes, with a small emerald check/status bar; do not use a stock shield glyph as the entire logo.
- **Signature brand color:** Guardian emerald `#047857`.

## Project structure

- `client/src/pages/Home.tsx` — assistant dashboard, navigation, voice/chat controls, code workspace, data analysis, security inspector, activity and settings.
- `client/src/index.css` — Clinical Guardian tokens, typography, layout, responsive rules, and motion.
- `client/src/lib/assistant-utils.ts` — browser-only CSV/JSON parsing, local descriptive statistics, and bounded heuristic file inspection.
- `server/assistantRouter.ts` — validated and rate-limited tRPC AI request endpoint for assistant/code/data/security guidance; server-side built-in LLM invocation only.
- `server/routers.ts` — register the assistant router with the existing app router.
- `client/public/manus-routes.json` — declare the current page route set before starting the dev server; this is the public directory configured by Vite.
- `TODO.md` — outcome-based acceptance items from the confirmed Blueprint and original request.

## Dependencies and serving

Reuse the initialized dependencies and managed Server-only configuration. Do not add a database, third-party keys, or new packages unless implementation requires them. The browser calls the existing tRPC API; the server uses the built-in LLM integration and receives platform credentials at runtime. Static file inspection and data parsing remain browser-local by default. Serve the root route and `/404` behavior through the existing web starter.
